import { z, _ } from "../chunks/2.Tbxs5yBc.js";
export {
  z as component,
  _ as universal
};
